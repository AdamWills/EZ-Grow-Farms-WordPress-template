<?php use Roots\Sage\Titles; ?>

<div class="page-header">
  <div class="content">
    <h1>EZ Grow</h1>
  </div>
</div>
