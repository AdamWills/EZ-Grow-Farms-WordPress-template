<?php use Roots\Sage\Assets; ?>

<div class="row medium-unstack">
  <div class="column">
      <img src="<?php echo Assets\asset_path('images/temp-3.jpg'); ?>" alt="">
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis modi nostrum ipsa minus accusamus beatae fugit, laboriosam natus optio dolorem incidunt asperiores voluptatum laborum libero. Atque illo distinctio deleniti dignissimos! Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste itaque, in consectetur animi corporis ab, alias recusandae reiciendis facilis et provident ipsa perspiciatis exercitationem quae ex reprehenderit nisi sapiente dicta?</p>
  </div>
  <div class="column">
    <img src="<?php echo Assets\asset_path('images/temp-2.jpg'); ?>" alt="">
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatibus omnis dolorum commodi, eligendi iure porro vero aspernatur est ullam, voluptas modi laboriosam incidunt atque! Quod tempore tempora fugit, atque ipsa. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam quisquam facere repudiandae dolore voluptatem ex nulla ducimus debitis sapiente quaerat eum quia, voluptate. Repellendus magnam distinctio architecto nihil, quis aliquam.</p>
  </div>
</div>
