
<footer class="content-info container">
  <div class="row medium-unstack">
    <div class="column">
      <div class="sitemap">
      [insert youtube here]
      </div>
    </div>
    <div class="column">
      <img src="http://www.ofvga.org/images/ofvga-logo.jpg">
    </div>
  </div>
  <div class="social-media">
    <ul class="icons">
      <li><a href="#"><?php get_template_part('dist/images/icon','facebook.svg'); ?></a></li>
      <li><a href="#"><?php get_template_part('dist/images/icon','instagram.svg'); ?></a></li>
      <li><a href="#"><?php get_template_part('dist/images/icon','twitter.svg'); ?></a></li>
    </ul>
  </div>
</footer>
